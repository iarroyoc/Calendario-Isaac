package es.isaac.calendario

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.util.Base64
import java.nio.charset.Charset

/** Widget nativo de agenda: muestra los próximos eventos guardados localmente. */
class AgendaWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id -> updateOne(context, manager, id) }
    }

    companion object {
        fun refresh(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, AgendaWidgetProvider::class.java)
            manager.getAppWidgetIds(component).forEach { updateOne(context, manager, it) }
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            val views = RemoteViews(context.packageName, R.layout.agenda_widget)
            val open = Intent(context, MainActivity::class.java)
            val pi = PendingIntent.getActivity(context, 7001, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_root, pi)
            views.setOnClickPendingIntent(R.id.widget_open, pi)

            val prefs = context.getSharedPreferences("calendar_isaac", Context.MODE_PRIVATE)
            val nowDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            val entries = prefs.getString("events", "").orEmpty().lines().filter { it.isNotBlank() }
                .mapNotNull { line ->
                    val parts = line.split("|")
                    if (parts.size == 4 && parts[1] >= nowDate) {
                        val title = try {
                            if (parts[0].startsWith("b64:")) String(Base64.decode(parts[0].removePrefix("b64:"), Base64.DEFAULT), Charset.forName("UTF-8"))
                            else parts[0]
                        } catch (_: Exception) { parts[0] }
                        Triple(parts[1], parts[2], title)
                    } else null
                }
                .sortedWith(compareBy<Triple<String, String, String>> { it.first }.thenBy { it.second })
                .take(3)
            val dateFormat = SimpleDateFormat("dd/MM", Locale("es", "ES"))
            val text = if (entries.isEmpty()) "No hay próximos eventos" else entries.joinToString("\n") {
                "${dateFormat.format(SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(it.first) ?: Date())}  ${it.second}  ${it.third}"
            }
            views.setTextViewText(R.id.widget_events, text)
            manager.updateAppWidget(id, views)
        }
    }
}
