package es.isaac.calendario

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Base64
import java.util.Calendar

/** Reprograma recordatorios después de reiniciar el móvil o cambiar la hora/zona horaria. */
class AlarmRescheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action !in setOf(
                Intent.ACTION_BOOT_COMPLETED,
                Intent.ACTION_MY_PACKAGE_REPLACED,
                Intent.ACTION_TIME_CHANGED,
                Intent.ACTION_TIMEZONE_CHANGED
            )) return

        val pending = goAsync()
        Thread {
            try {
                val prefs = context.getSharedPreferences("calendar_isaac", Context.MODE_PRIVATE)
                val rows = prefs.getString("events", "").orEmpty().lines()
                val manager = context.getSystemService(AlarmManager::class.java)
                rows.filter { it.isNotBlank() }.forEach { row ->
                    val p = row.split("|", limit = 4)
                    if (p.size != 4) return@forEach
                    try {
                        val title = if (p[0].startsWith("b64:"))
                            String(Base64.decode(p[0].removePrefix("b64:"), Base64.DEFAULT), Charsets.UTF_8)
                        else p[0]
                        val date = p[1].split("-").map { it.toInt() }
                        val time = p[2].split(":").map { it.toInt() }
                        val mins = p[3].toInt()
                        if (date.size != 3 || time.size != 2 || mins < 0) return@forEach
                        val whenToRing = Calendar.getInstance().apply {
                            set(date[0], date[1] - 1, date[2], time[0], time[1], 0)
                            set(Calendar.MILLISECOND, 0)
                            add(Calendar.MINUTE, -mins)
                        }.timeInMillis
                        if (whenToRing <= System.currentTimeMillis()) return@forEach
                        val alarmIntent = Intent(context, AlarmReceiver::class.java).apply {
                            putExtra("title", title); putExtra("date", p[1]); putExtra("time", p[2])
                        }
                        val requestCode = (title + p[1] + p[2]).hashCode()
                        val pi = PendingIntent.getBroadcast(context, requestCode, alarmIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                        try {
                            if (Build.VERSION.SDK_INT >= 31 && !manager.canScheduleExactAlarms())
                                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenToRing, pi)
                            else manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenToRing, pi)
                        } catch (_: SecurityException) {
                            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenToRing, pi)
                        }
                    } catch (_: Exception) { /* Ignorar filas antiguas o dañadas sin perder las demás. */ }
                }
            } finally { pending.finish() }
        }.start()
    }
}
