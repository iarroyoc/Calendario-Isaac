package es.isaac.calendario

import android.app.*
import android.content.*
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.net.Uri
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import android.util.Base64
import java.text.SimpleDateFormat
import java.util.*

data class CalendarEvent(val title: String, val date: String, val time: String, val reminderMinutes: Int)

class MainActivity : Activity() {
    private val events = mutableListOf<CalendarEvent>()
    private lateinit var list: LinearLayout
    private val prefs by lazy { getSharedPreferences("calendar_isaac", MODE_PRIVATE) }
    private val exportRequest = 4101
    private val importRequest = 4102
    private var viewMode = "Mes"
    private var selectedDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private var displayedMonth = Calendar.getInstance()
    private var searchText = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannels()
        loadEvents()
        // Recupera los recordatorios al abrir la app, sin mostrar un diálogo por cada evento.
        events.forEach { scheduleAlarm(it, showPermissionDialog = false) }
        render()
        askNotificationPermission()
    }

    private fun createChannels() {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("calendar_alarm", "Alarmas del calendario", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Avisos de eventos a pantalla completa"
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                enableVibration(true)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun askNotificationPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 20)
            setBackgroundColor(Color.rgb(248, 249, 252))
        }
        val title = TextView(this).apply {
            text = "Calendario Isaac"
            textSize = 28f
            setTextColor(Color.rgb(25, 35, 55))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = SimpleDateFormat("EEEE, d 'de' MMMM", Locale("es", "ES")).format(Date()).replaceFirstChar { it.uppercase() }
            textSize = 15f
            setPadding(0, 4, 0, 18)
            setTextColor(Color.DKGRAY)
        }
        root.addView(subtitle)

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Mes", "Semana", "Día", "Agenda").forEach { label ->
            buttons.addView(Button(this).apply {
                text = label
                isAllCaps = false
                setOnClickListener { viewMode = label; render() }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(buttons)

        val monthNavigation = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        monthNavigation.addView(Button(this).apply { text = "‹"; contentDescription = "Mes anterior"; setOnClickListener { displayedMonth.add(Calendar.MONTH, -1); render() } }, LinearLayout.LayoutParams(52, ViewGroup.LayoutParams.WRAP_CONTENT))
        val monthLabel = TextView(this).apply {
            text = SimpleDateFormat("MMMM yyyy", Locale("es", "ES")).format(displayedMonth.time).replaceFirstChar { it.uppercase() }
            textSize = 21f
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(4, 18, 4, 8)
            setTextColor(Color.rgb(25, 35, 55))
        }
        monthNavigation.addView(monthLabel, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        monthNavigation.addView(Button(this).apply { text = "›"; contentDescription = "Mes siguiente"; setOnClickListener { displayedMonth.add(Calendar.MONTH, 1); render() } }, LinearLayout.LayoutParams(52, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(monthNavigation)
        val weekdays = TextView(this).apply {
            text = " L     M     X     J     V     S     D"
            textSize = 14f
            setTextColor(Color.GRAY)
        }
        root.addView(weekdays)
        val grid = GridLayout(this).apply { columnCount = 7 }
        val first = (displayedMonth.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, 1) }
        val offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7
        repeat(offset) { grid.addView(TextView(this).apply { text = " " }, GridLayout.LayoutParams().apply { width = 0; columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f) }) }
        val days = displayedMonth.getActualMaximum(Calendar.DAY_OF_MONTH)
        for (d in 1..days) {
            val cell = TextView(this).apply {
                text = d.toString()
                gravity = Gravity.CENTER
                textSize = 16f
                setTextColor(Color.rgb(35, 45, 60))
                setPadding(0, 12, 0, 12)
                val cellDate = String.format(Locale.US, "%04d-%02d-%02d", displayedMonth.get(Calendar.YEAR), displayedMonth.get(Calendar.MONTH) + 1, d)
                val hasEvent = events.any { it.date == cellDate }
                if (cellDate == selectedDate) setBackgroundColor(Color.rgb(190, 215, 255))
                else if (hasEvent) setBackgroundColor(Color.rgb(225, 242, 228))
                else if (d == Calendar.getInstance().get(Calendar.DAY_OF_MONTH) && displayedMonth.get(Calendar.MONTH) == Calendar.getInstance().get(Calendar.MONTH) && displayedMonth.get(Calendar.YEAR) == Calendar.getInstance().get(Calendar.YEAR)) setBackgroundColor(Color.rgb(238, 241, 246))
                setOnClickListener { selectedDate = cellDate; render() }
            }
            grid.addView(cell, GridLayout.LayoutParams().apply {
                width = 0; height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            })
        }
        root.addView(grid)
        root.addView(TextView(this).apply {
            text = "Seleccionado: $selectedDate  ·  Verde: hay eventos"
            textSize = 12f; setTextColor(Color.GRAY); setPadding(0, 4, 0, 8)
        })
        val search = EditText(this).apply {
            hint = "Buscar eventos por título"
            setSingleLine(true)
            setText(searchText)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { searchText = s?.toString().orEmpty(); renderEventListOnly() }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        root.addView(search)

        val add = Button(this).apply {
            text = "+ Añadir evento"
            isAllCaps = false
            setOnClickListener { addEventDialog() }
        }
        root.addView(add)
        val backupButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        backupButtons.addView(Button(this).apply {
            text = "Exportar copia"; isAllCaps = false
            setOnClickListener {
                val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "text/plain"
                    putExtra(Intent.EXTRA_TITLE, "CalendarioIsaac.cia")
                }
                startActivityForResult(i, exportRequest)
            }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        backupButtons.addView(Button(this).apply {
            text = "Importar copia"; isAllCaps = false
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                }
                startActivityForResult(i, importRequest)
            }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(backupButtons)
        val eventsTitle = TextView(this).apply {
            text = "Próximos eventos"
            textSize = 20f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 18, 0, 8)
            setTextColor(Color.rgb(25, 35, 55))
        }
        root.addView(eventsTitle)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        renderEventListOnly()
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun renderEventListOnly() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val weekStart = Calendar.getInstance().apply {
            try { val p = selectedDate.split("-").map { it.toInt() }; set(p[0], p[1] - 1, p[2], 0, 0, 0) } catch (_: Exception) { }
            set(Calendar.DAY_OF_WEEK, firstDayOfWeek); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val weekEnd = (weekStart.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 7) }
        val filtered = events.withIndex().filter { indexed ->
            val e = indexed.value
            val matchesSearch = searchText.isBlank() || e.title.contains(searchText, ignoreCase = true)
            val dateCal = Calendar.getInstance().apply {
                try { val p = e.date.split("-").map { it.toInt() }; set(p[0], p[1] - 1, p[2], 12, 0, 0) } catch (_: Exception) { timeInMillis = 0L }
            }
            val matchesMode = when (viewMode) {
                "Día" -> e.date == selectedDate
                "Semana" -> dateCal.timeInMillis >= weekStart.timeInMillis && dateCal.timeInMillis < weekEnd.timeInMillis
                "Agenda" -> dateCal.timeInMillis >= System.currentTimeMillis() - 86400000L
                else -> true
            }
            matchesSearch && matchesMode
        }.sortedWith(compareBy<IndexedValue<CalendarEvent>> { it.value.date }.thenBy { it.value.time })
        if (filtered.isEmpty()) {
            list.addView(TextView(this).apply {
                text = if (searchText.isNotBlank()) "No hay eventos que coincidan con la búsqueda." else "No hay eventos para la vista seleccionada."
                textSize = 15f; setTextColor(Color.GRAY); setPadding(0, 10, 0, 10)
            })
        } else filtered.forEach { indexed ->
            val event = indexed.value
            val row = TextView(this).apply {
                text = "●  ${event.date}  ${event.time}  ${event.title}\n     Alarma ${event.reminderMinutes} min antes"
                textSize = 15f; setTextColor(Color.rgb(35, 45, 60)); setPadding(12, 12, 12, 12); setBackgroundColor(Color.WHITE)
                setOnClickListener { editEventDialog(indexed.index) }
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity).setTitle("Eliminar evento")
                        .setMessage("¿Quieres eliminar «${event.title}»?")
                        .setNegativeButton("Cancelar", null)
                        .setPositiveButton("Eliminar") { _, _ -> cancelAlarm(event); events.remove(event); saveEvents(); render() }
                        .show(); true
                }
            }
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        }
        list.addView(TextView(this).apply { text = "Toca un evento para editarlo; mantenlo pulsado para eliminarlo."; textSize = 12f; setTextColor(Color.GRAY) })
    }

    private fun addEventDialog() = eventDialog(null)

    private fun editEventDialog(index: Int) {
        if (index in events.indices) eventDialog(index)
    }

    private fun eventDialog(editIndex: Int?) {
        val oldEvent = editIndex?.let { events.getOrNull(it) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 8, 28, 0)
        }
        val titleInput = EditText(this).apply { hint = "Título del evento"; textSize = 16f; setText(oldEvent?.title.orEmpty()) }
        box.addView(titleInput)
        val dateButton = Button(this).apply { text = oldEvent?.let { "Fecha: ${it.date}" } ?: "Elegir fecha"; isAllCaps = false }
        val timeButton = Button(this).apply { text = "Hora: ${oldEvent?.time ?: "12:00"}"; isAllCaps = false }
        val reminderSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Avisar a la hora", "5 minutos antes", "10 minutos antes", "15 minutos antes", "30 minutos antes", "1 hora antes"))
        }
        oldEvent?.let { reminderSpinner.setSelection(when (it.reminderMinutes) { 5 -> 1; 10 -> 2; 15 -> 3; 30 -> 4; 60 -> 5; else -> 0 }) }
        box.addView(dateButton); box.addView(timeButton); box.addView(reminderSpinner)
        var chosenDate = oldEvent?.date ?: SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        var hour = oldEvent?.time?.substringBefore(":")?.toIntOrNull() ?: 12
        var minute = oldEvent?.time?.substringAfter(":")?.toIntOrNull() ?: 0
        dateButton.setOnClickListener {
            val c = Calendar.getInstance().apply {
                try {
                    val parts = chosenDate.split("-").map { it.toInt() }
                    if (parts.size == 3) set(parts[0], parts[1] - 1, parts[2])
                } catch (_: Exception) { }
            }
            DatePickerDialog(this, { _, y, m, d ->
                chosenDate = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)
                dateButton.text = "Fecha: $chosenDate"
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
        }
        timeButton.setOnClickListener {
            DigitalTimeDialog(this, hour, minute) { h, m ->
                hour = h; minute = m
                timeButton.text = String.format(Locale.US, "Hora: %02d:%02d", h, m)
            }.show()
        }
        AlertDialog.Builder(this).setTitle(if (oldEvent == null) "Nuevo evento" else "Editar evento").setView(box)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar") { _, _ ->
                val name = titleInput.text.toString().trim()
                if (name.isEmpty()) { Toast.makeText(this, "Escribe el título del evento", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                val mins = when (reminderSpinner.selectedItemPosition) { 1 -> 5; 2 -> 10; 3 -> 15; 4 -> 30; 5 -> 60; else -> 0 }
                val time = String.format(Locale.US, "%02d:%02d", hour, minute)
                val event = CalendarEvent(name, chosenDate, time, mins)
                if (editIndex != null && oldEvent != null) {
                    cancelAlarm(oldEvent)
                    events.removeAt(editIndex)
                }
                events.add(event); saveEvents(); scheduleAlarm(event); AgendaWidgetProvider.refresh(this); render()
            }.show()
    }

    private fun cancelAlarm(event: CalendarEvent) {
        try {
            val intent = Intent(this, AlarmReceiver::class.java).apply {
                putExtra("title", event.title); putExtra("date", event.date); putExtra("time", event.time)
            }
            val requestCode = (event.title + event.date + event.time).hashCode()
            val pi = PendingIntent.getBroadcast(this, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            getSystemService(AlarmManager::class.java).cancel(pi)
            pi.cancel()
        } catch (_: Exception) { }
    }

    private fun scheduleAlarm(event: CalendarEvent, showPermissionDialog: Boolean = true) {
        try {
            val parts = event.date.split("-").map { it.toInt() }
            val hm = event.time.split(":").map { it.toInt() }
            val cal = Calendar.getInstance().apply {
                set(parts[0], parts[1] - 1, parts[2], hm[0], hm[1], 0)
                set(Calendar.MILLISECOND, 0)
                add(Calendar.MINUTE, -event.reminderMinutes)
            }
            if (cal.timeInMillis <= System.currentTimeMillis()) return
            val intent = Intent(this, AlarmReceiver::class.java).apply {
                putExtra("title", event.title); putExtra("date", event.date); putExtra("time", event.time)
            }
            val pi = PendingIntent.getBroadcast(this, (event.title + event.date + event.time).hashCode(),
                intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val am = getSystemService(AlarmManager::class.java)
            if (android.os.Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                if (showPermissionDialog) {
                    AlertDialog.Builder(this)
                        .setTitle("Permiso de alarmas exactas")
                        .setMessage("Para que los recordatorios suenen a la hora elegida, permite las alarmas exactas en los ajustes de Calendario Isaac. Mientras tanto se programará un aviso aproximado.")
                        .setPositiveButton("Abrir ajustes") { _, _ ->
                            try {
                                startActivity(Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                    android.net.Uri.parse("package:$packageName")))
                            } catch (_: Exception) { }
                        }
                        .setNegativeButton("Ahora no", null).show()
                }
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            }
        } catch (_: Exception) {
            Toast.makeText(this, "No se pudo programar la alarma.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveEvents() {
        // Codificar el título evita que los separadores o saltos de línea rompan el archivo local.
        val encoded = events.joinToString("\n") {
            val safeTitle = "b64:" + Base64.encodeToString(it.title.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            listOf(safeTitle, it.date, it.time, it.reminderMinutes.toString()).joinToString("|")
        }
        prefs.edit().putString("events", encoded).apply()
        AgendaWidgetProvider.refresh(this)
    }

    @Deprecated("Selector de archivos del sistema")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        try {
            if (requestCode == 4101) {
                contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { out ->
                    out.write("# Calendario Isaac backup v1\n")
                    events.forEach { e ->
                        val encodedTitle = Base64.encodeToString(e.title.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
                        out.write("$encodedTitle|${e.date}|${e.time}|${e.reminderMinutes}\n")
                    }
                }
                Toast.makeText(this, "Copia exportada correctamente", Toast.LENGTH_LONG).show()
            } else if (requestCode == 4102) {
                val imported = mutableListOf<CalendarEvent>()
                contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.useLines { lines ->
                    lines.filter { it.isNotBlank() && !it.startsWith("#") }.forEach { line ->
                        val p = line.split("|")
                        if (p.size == 4) try {
                            val title = String(Base64.decode(p[0], Base64.DEFAULT), Charsets.UTF_8)
                            val dateOk = p[1].matches(Regex("\\d{4}-\\d{2}-\\d{2}"))
                            val timeOk = p[2].matches(Regex("\\d{2}:\\d{2}"))
                            val mins = p[3].toInt()
                            if (title.isNotBlank() && dateOk && timeOk && mins >= 0) imported.add(CalendarEvent(title, p[1], p[2], mins))
                        } catch (_: Exception) { }
                    }
                }
                if (imported.isEmpty()) Toast.makeText(this, "No se encontraron eventos válidos", Toast.LENGTH_LONG).show()
                else AlertDialog.Builder(this).setTitle("Restaurar copia")
                    .setMessage("Se han encontrado ${imported.size} eventos. ¿Quieres reemplazar los eventos actuales?")
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Restaurar") { _, _ ->
                        // Cancela las alarmas existentes antes de sustituir los eventos.
                        events.forEach { cancelAlarm(it) }
                        events.clear(); events.addAll(imported); saveEvents(); events.forEach { scheduleAlarm(it, showPermissionDialog = false) }; render()
                        Toast.makeText(this, "Copia restaurada", Toast.LENGTH_LONG).show()
                    }.show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo procesar la copia", Toast.LENGTH_LONG).show()
        }
    }

    private fun loadEvents() {
        prefs.getString("events", "")!!.lines().filter { it.isNotBlank() }.forEach { line ->
            val p = line.split("|", limit = 4)
            if (p.size == 4) {
                val title = try {
                    if (p[0].startsWith("b64:")) String(Base64.decode(p[0].removePrefix("b64:"), Base64.DEFAULT), Charsets.UTF_8)
                    else p[0] // compatibilidad con datos guardados por versiones anteriores
                } catch (_: Exception) { p[0] }
                val validDate = p[1].matches(Regex("\\d{4}-\\d{2}-\\d{2}"))
                val validTime = p[2].matches(Regex("\\d{2}:\\d{2}"))
                val mins = p[3].toIntOrNull()
                if (title.isNotBlank() && validDate && validTime && mins != null && mins >= 0)
                    events.add(CalendarEvent(title, p[1], p[2], mins))
            }
        }
    }
}

class DigitalTimeDialog(
    private val activity: Activity,
    startHour: Int,
    startMinute: Int,
    private val onSelected: (Int, Int) -> Unit
) {
    private val context = activity
    private var hourText = String.format(Locale.US, "%02d", startHour)
    private var minuteText = String.format(Locale.US, "%02d", startMinute)
    fun show() {
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 18, 24, 12)
        }
        val heading = TextView(context).apply {
            text = "Seleccionar hora"
            textSize = 23f; setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(heading)
        val display = TextView(context).apply {
            textSize = 48f; gravity = Gravity.CENTER; setPadding(0, 12, 0, 12)
        }
        root.addView(display)
        var entry = StringBuilder()
        fun refresh() { display.text = "${hourText}:${minuteText}" }
        val grid = GridLayout(context).apply { columnCount = 3 }
        val keys = listOf("1","2","3","4","5","6","7","8","9",":00","0",":30")
        keys.forEach { key ->
            val b = Button(context).apply {
                text = key; textSize = 20f; isAllCaps = false
                setOnClickListener {
                    when (key) {
                        ":00" -> { minuteText = "00"; entry.clear() }
                        ":30" -> { minuteText = "30"; entry.clear() }
                        else -> {
                            entry.append(key)
                            if (entry.length >= 4) {
                                val h = entry.substring(0, 2).toIntOrNull()
                                val m = entry.substring(2, 4).toIntOrNull()
                                if (h != null && m != null && h in 0..23 && m in 0..59) {
                                    hourText = String.format(Locale.US, "%02d", h)
                                    minuteText = String.format(Locale.US, "%02d", m)
                                }
                                entry.clear()
                            } else if (entry.length == 2) {
                                val h = entry.toString().toIntOrNull()
                                if (h != null && h in 0..23) hourText = String.format(Locale.US, "%02d", h)
                            }
                        }
                    }
                    refresh()
                }
            }
            grid.addView(b, GridLayout.LayoutParams().apply {
                width = 0; height = 58
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(3, 3, 3, 3)
            })
        }
        root.addView(grid)
        val erase = Button(context).apply {
            text = "⌫  Borrar"; isAllCaps = false
            setOnClickListener { entry.clear(); hourText = "00"; minuteText = "00"; refresh() }
        }
        root.addView(erase)
        refresh()
        AlertDialog.Builder(context).setView(root)
            .setNegativeButton("CANCELAR", null)
            .setPositiveButton("ACEPTAR") { _, _ ->
                onSelected(hourText.toIntOrNull() ?: 12, minuteText.toIntOrNull() ?: 0)
            }.show()
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Recordatorio"
        val date = intent.getStringExtra("date") ?: ""
        val time = intent.getStringExtra("time") ?: ""
        // Cada evento debe tener su propio identificador: dos eventos con el mismo título
        // no deben sobrescribirse ni detener la alarma equivocada.
        val alarmId = (title + "|" + date + "|" + time).hashCode()
        val activityIntent = Intent(context, AlarmActivity::class.java).apply {
            putExtra("title", title)
            putExtra("date", date)
            putExtra("time", time)
            putExtra("alarmId", alarmId)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        val fullScreen = PendingIntent.getActivity(context, alarmId, activityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = Notification.Builder(context, "calendar_alarm")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Recordatorio")
            .setContentText(title)
            .setCategory(Notification.CATEGORY_ALARM)
            .setPriority(Notification.PRIORITY_MAX)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setFullScreenIntent(fullScreen, true)
            .setContentIntent(fullScreen)
            .setOngoing(true)
            .setAutoCancel(false)
            .build()
        context.getSystemService(NotificationManager::class.java).notify(alarmId, notification)
        try { context.startActivity(activityIntent) } catch (_: Exception) { /* Android puede limitar el inicio desde segundo plano */ }
    }
}

class AlarmActivity : Activity() {
    private var tone: android.media.MediaPlayer? = null
    private var alarmNotificationId: Int = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true); setTurnScreenOn(true)
        }
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        val title = intent.getStringExtra("title") ?: "Recordatorio"
        alarmNotificationId = intent.getIntExtra("alarmId", (title + "|" + (intent.getStringExtra("date") ?: "") + "|" + (intent.getStringExtra("time") ?: "")).hashCode())
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32); setBackgroundColor(Color.rgb(20, 29, 48))
        }
        root.addView(TextView(this).apply {
            text = "ALARMA DEL CALENDARIO"; textSize = 16f; setTextColor(Color.LTGRAY)
        })
        root.addView(TextView(this).apply {
            text = title; textSize = 32f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); setPadding(0, 30, 0, 18)
        })
        root.addView(TextView(this).apply {
            text = "${intent.getStringExtra("date") ?: ""}  ${intent.getStringExtra("time") ?: ""}"
            textSize = 18f; setTextColor(Color.LTGRAY); setPadding(0, 0, 0, 32)
        })
        val stop = Button(this).apply {
            text = "DETENER ALARMA"; isAllCaps = false
            setOnClickListener { stopAlarm(); finish() }
        }
        root.addView(stop, LinearLayout.LayoutParams(-1, -2))
        val snooze = Button(this).apply {
            text = "POSPONER 5 MIN"; isAllCaps = false
            setOnClickListener {
                val i = Intent(this@AlarmActivity, AlarmReceiver::class.java).apply {
                    putExtra("title", title); putExtra("date", intent.getStringExtra("date")); putExtra("time", intent.getStringExtra("time"))
                }
                val pi = PendingIntent.getBroadcast(this@AlarmActivity, (title + "|" + (intent.getStringExtra("date") ?: "") + "|" + (intent.getStringExtra("time") ?: "") + "|snooze").hashCode(), i,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val alarmManager = getSystemService(AlarmManager::class.java)
                val snoozeAt = System.currentTimeMillis() + 5 * 60 * 1000
                try {
                    if (android.os.Build.VERSION.SDK_INT >= 31 && !alarmManager.canScheduleExactAlarms())
                        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, snoozeAt, pi)
                    else alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, snoozeAt, pi)
                } catch (_: SecurityException) {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, snoozeAt, pi)
                }
                stopAlarm(); finish()
            }
        }
        root.addView(snooze, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        try {
            tone = android.media.MediaPlayer.create(this, android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI)
            tone?.isLooping = true; tone?.start()
        } catch (_: Exception) {}
    }
    private fun stopAlarm() {
        try { tone?.stop(); tone?.release() } catch (_: Exception) {}
        tone = null
        getSystemService(NotificationManager::class.java).cancel(alarmNotificationId)
    }
    override fun onDestroy() { stopAlarm(); super.onDestroy() }
}
