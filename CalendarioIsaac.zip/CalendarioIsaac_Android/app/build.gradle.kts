plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "es.isaac.calendario"
    compileSdk = 35
    defaultConfig {
        applicationId = "es.isaac.calendario"
        minSdk = 26
        targetSdk = 35
        versionCode = 12
        versionName = "1.2.0"
    }
}
