CALENDARIO ISAAC 1.2.0 — PROYECTO ANDROID
========================================

Destino: teléfonos Android (objetivo de pruebas: HONOR 90 / Android 15).
Paquete: es.isaac.calendario

Funciones incluidas en este proyecto:
- Calendario mensual básico y creación de eventos.
- Selector digital de hora de 24 horas.
- Recordatorios con notificación de alta prioridad, sonido y pantalla de alarma.
- Botones para detener y posponer 5 minutos.
- Exportación e importación de copias locales de eventos.
- Widget de agenda para la pantalla de inicio.
- Reprogramación de recordatorios tras reinicio, actualización de la app o cambio de hora/zona horaria.
- Al abrir la aplicación vuelve a programar recordatorios futuros guardados, sin abrir múltiples avisos de permisos.
- La lista de eventos se muestra ordenada por fecha y hora.
- Compatibilidad de lectura con los títulos guardados por versiones anteriores.

IMPORTANTE SOBRE LA COMPILACIÓN
Este ZIP contiene el código fuente. No incluye un APK compilado. El entorno en el que se preparó no dispone de Android SDK/Gradle ni de acceso a los repositorios para instalarlos, por lo que no se ha podido compilar ni probar en un teléfono.

Cómo generar un APK con GitHub Actions:
1. Sube el contenido de esta carpeta a un repositorio de GitHub.
2. Abre la pestaña Actions y habilita los flujos si GitHub lo solicita.
3. Ejecuta “Compilar Calendario Isaac APK” mediante Run workflow (o realiza un push a main/master).
4. Cuando termine correctamente, abre la ejecución y descarga el artefacto “Calendario-Isaac-1.2.0-debug-apk”.
5. Dentro encontrarás app-debug.apk y SHA256SUMS.txt.

El APK de depuración generado por Gradle está firmado con una clave de depuración automática y es adecuado para instalar y probar. No equivale a una versión de publicación firmada con una clave privada propia.

Limitaciones funcionales aún pendientes:
- Vistas semanal y diaria completas.
- Edición avanzada y recurrencia de eventos.
- Sincronización con Google Calendar y Dropbox.
- Widget mensual.
- Pruebas reales de alarmas en Android 15/HONOR; Android y el fabricante pueden limitar el inicio automático a pantalla completa y el funcionamiento en segundo plano.


COMPILACIÓN AUTOMÁTICA DEL APK (v0.7.0)
1. Sube el contenido de esta carpeta a un repositorio GitHub.
2. Abre la pestaña Actions y selecciona “Compilar Calendario Isaac APK”.
3. Pulsa “Run workflow” y espera a que termine en verde.
4. En el resultado, descarga el artefacto “Calendario-Isaac-1.2.0-debug-apk”; dentro está app-debug.apk.

El flujo verifica que el APK exista y publica su SHA-256. La compilación automática aún debe ejecutarse en GitHub; este archivo ZIP no contiene un APK compilado.

Versión 0.8.0: permite tocar un evento para editarlo y mantener pulsado para eliminarlo; al editar o borrar intenta cancelar la alarma antigua antes de actualizar el calendario.
Versión 0.9.0: declara el permiso de arranque necesario para reprogramar recordatorios tras reiniciar; al editar un evento, el selector de fecha se abre en la fecha actual del evento; al restaurar una copia, cancela las alarmas anteriores antes de sustituir los eventos.

El APK sigue pendiente de una compilación real en un entorno Android SDK/Gradle.

Versión 1.1.0: corregida una referencia de variable incorrecta en el cálculo de días del mes, que impedía compilar MainActivity. Actualizados versionCode, versionName y el nombre del artefacto de compilación.

Versión 1.2.0: cada alarma usa un identificador derivado de título, fecha y hora para evitar que eventos con el mismo título sobrescriban sus notificaciones; el aviso queda persistente, permite abrir la pantalla de alarma desde la notificación y la posposición utiliza una solicitud independiente. Actualizados versionCode, versionName y artefacto.
